
class TargetNotFoundError(Exception):
    pass

class FriendNotFoundError(Exception):
    pass

class WeChatNotFoundError(Exception):
    pass